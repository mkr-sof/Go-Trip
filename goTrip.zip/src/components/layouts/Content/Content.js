
function Content({ children, className }) {
    return children;
}

export default Content;