goTripExpo
├── .expo
├── app
    ├──index.js
├── components
│   ├── App
│   │   ├── App.js
│   │   └── App.module.scss
|   ├── common
|   ├──features
│   └── layouts

├── app.json
└── index.js          
