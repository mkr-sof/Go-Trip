goTrip/
└── src/
    ├── assets/
    ├── components/
    │   ├── App/
    │   ├── common/
    │   ├── features/
    │   │   ├── Auth/
    │   │   ├── Feed/
    │   │   ├── Profile/
    │   │   └── NotFound/
    ├── layouts/
    ├── hooks/
    ├── routes/
    └── store/
